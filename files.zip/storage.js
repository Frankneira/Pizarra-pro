/**
 * storage.js - Gestión de localStorage y sessionStorage
 */

const STORAGE_KEYS = {
  CANVAS_DATA: 'pizarra_canvas_data',
  CANVAS_TIMESTAMP: 'pizarra_timestamp',
  USER_PREFERENCES: 'pizarra_preferences',
  THEME: 'pizarra_theme',
  HISTORY: 'pizarra_history'
}

/**
 * Guardar datos del canvas
 */
export function saveCanvasData(canvasJSON) {
  try {
    const data = {
      canvas: canvasJSON,
      timestamp: new Date().toISOString(),
      version: '1.0.0'
    }
    localStorage.setItem(STORAGE_KEYS.CANVAS_DATA, JSON.stringify(data))
    return true
  } catch (error) {
    console.error('Error guardando canvas:', error)
    return false
  }
}

/**
 * Cargar datos del canvas
 */
export function loadCanvasData() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CANVAS_DATA)
    return data ? JSON.parse(data) : null
  } catch (error) {
    console.error('Error cargando canvas:', error)
    return null
  }
}

/**
 * Guardar preferencias del usuario
 */
export function saveUserPreferences(preferences) {
  try {
    localStorage.setItem(STORAGE_KEYS.USER_PREFERENCES, JSON.stringify(preferences))
    return true
  } catch (error) {
    console.error('Error guardando preferencias:', error)
    return false
  }
}

/**
 * Cargar preferencias del usuario
 */
export function loadUserPreferences() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.USER_PREFERENCES)
    return data ? JSON.parse(data) : getDefaultPreferences()
  } catch (error) {
    console.error('Error cargando preferencias:', error)
    return getDefaultPreferences()
  }
}

/**
 * Preferencias por defecto
 */
function getDefaultPreferences() {
  return {
    brushSize: 3,
    brushColor: '#000000',
    theme: 'light',
    autoSave: true,
    autoSaveInterval: 60000
  }
}

/**
 * Guardar tema
 */
export function saveTheme(theme) {
  try {
    localStorage.setItem(STORAGE_KEYS.THEME, theme)
    return true
  } catch (error) {
    console.error('Error guardando tema:', error)
    return false
  }
}

/**
 * Cargar tema
 */
export function loadTheme() {
  try {
    const theme = localStorage.getItem(STORAGE_KEYS.THEME)
    return theme || 'light'
  } catch (error) {
    console.error('Error cargando tema:', error)
    return 'light'
  }
}

/**
 * Limpiar todos los datos
 */
export function clearAllData() {
  try {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key)
    })
    return true
  } catch (error) {
    console.error('Error limpiando datos:', error)
    return false
  }
}

/**
 * Obtener tamaño de almacenamiento usado
 */
export function getStorageSize() {
  let size = 0
  try {
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        size += localStorage[key].length + key.length
      }
    }
    return (size / 1024).toFixed(2) + ' KB'
  } catch (error) {
    return '0 KB'
  }
}

/**
 * Exportar todos los datos a archivo
 */
export function exportDataToFile() {
  try {
    const data = {
      canvas: localStorage.getItem(STORAGE_KEYS.CANVAS_DATA),
      preferences: localStorage.getItem(STORAGE_KEYS.USER_PREFERENCES),
      theme: localStorage.getItem(STORAGE_KEYS.THEME),
      exportDate: new Date().toISOString()
    }

    const dataStr = JSON.stringify(data, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `pizarra-backup-${new Date().toISOString().slice(0, 10)}.json`
    link.click()
    URL.revokeObjectURL(url)

    return true
  } catch (error) {
    console.error('Error exportando datos:', error)
    return false
  }
}

/**
 * Importar datos desde archivo
 */
export async function importDataFromFile(file) {
  return new Promise((resolve, reject) => {
    try {
      const reader = new FileReader()
      
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result)
          
          if (data.canvas) {
            localStorage.setItem(STORAGE_KEYS.CANVAS_DATA, data.canvas)
          }
          if (data.preferences) {
            localStorage.setItem(STORAGE_KEYS.USER_PREFERENCES, data.preferences)
          }
          if (data.theme) {
            localStorage.setItem(STORAGE_KEYS.THEME, data.theme)
          }
          
          resolve(true)
        } catch (error) {
          reject(new Error('Formato de archivo inválido'))
        }
      }

      reader.onerror = () => {
        reject(new Error('Error al leer el archivo'))
      }

      reader.readAsText(file)
    } catch (error) {
      reject(error)
    }
  })
}
