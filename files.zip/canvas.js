/**
 * canvas.js - Gestión del canvas de dibujo con Fabric.js
 */

import { fabric } from 'fabric'

/**
 * Inicializar canvas de Fabric.js
 */
export async function initializeCanvas(canvasElement) {
  try {
    // Crear instancia de Fabric Canvas
    const canvas = new fabric.Canvas(canvasElement, {
      isDrawingMode: true,
      backgroundColor: '#ffffff',
      preserveObjectStacking: true,
      selection: true,
      selectable: true,
      uniformScaling: false,
      centeredRotation: false
    })

    // Configurar brush
    canvas.freeDrawingBrush = new fabric.PencilBrush(canvas)
    canvas.freeDrawingBrush.color = '#000000'
    canvas.freeDrawingBrush.width = 3
    canvas.freeDrawingBrush.shadowBlur = 0

    // Resize canvas al contenedor
    resizeCanvasToContainer(canvas, canvasElement)

    // Event listeners
    setupCanvasEvents(canvas)

    return canvas
  } catch (error) {
    console.error('Error inicializando canvas:', error)
    throw error
  }
}

/**
 * Redimensionar canvas al contenedor
 */
export function resizeCanvasToContainer(canvas, canvasElement) {
  const container = canvasElement.parentElement
  const width = container?.offsetWidth || 800
  const height = container?.offsetHeight || 600

  canvas.setWidth(width)
  canvas.setHeight(height)
  canvas.renderAll()
}

/**
 * Setup de eventos del canvas
 */
function setupCanvasEvents(canvas) {
  // Eventos de dibujo
  canvas.on('mouse:down', (e) => {
    console.log('Drawing started')
  })

  canvas.on('mouse:up', (e) => {
    console.log('Drawing ended')
  })

  // Resize responsivo
  window.addEventListener('resize', () => {
    resizeCanvasToContainer(canvas, canvas.getElement())
  })
}

/**
 * Exportar canvas a diferentes formatos
 */
export function exportCanvasAs(canvas, format = 'png') {
  const options = {
    format: format,
    quality: 1,
    multiplier: 2
  }

  return canvas.toDataURL(options)
}

/**
 * Limpiar canvas
 */
export function clearCanvas(canvas) {
  canvas.clear()
  canvas.renderAll()
}

/**
 * Obtener JSON del canvas (para guardar)
 */
export function getCanvasJSON(canvas) {
  return JSON.stringify(canvas.toJSON())
}

/**
 * Cargar canvas desde JSON
 */
export async function loadCanvasFromJSON(canvas, jsonString) {
  return new Promise((resolve, reject) => {
    try {
      canvas.loadFromJSON(jsonString, () => {
        canvas.renderAll()
        resolve()
      })
    } catch (error) {
      reject(error)
    }
  })
}
