/**
 * toolbar.js - Gestión de la barra de herramientas
 */

/**
 * Inicializar toolbar
 */
export async function initializeToolbar(appState) {
  try {
    const toolbar = document.getElementById('toolbar')
    if (!toolbar) {
      console.warn('Toolbar element not found')
      return
    }

    // Crear botones de la toolbar
    const buttons = [
      {
        id: 'save-btn',
        label: 'Guardar',
        icon: '💾',
        title: 'Guardar trabajo'
      },
      {
        id: 'load-btn',
        label: 'Cargar',
        icon: '📂',
        title: 'Cargar trabajo guardado'
      },
      {
        id: 'theme-toggle',
        label: 'Tema',
        icon: '🌙',
        title: 'Cambiar tema'
      }
    ]

    buttons.forEach(btn => {
      const button = document.createElement('button')
      button.id = btn.id
      button.className = 'px-3 py-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition flex items-center gap-2'
      button.title = btn.title
      button.innerHTML = `<span>${btn.icon}</span> <span class="text-sm">${btn.label}</span>`
      toolbar.appendChild(button)
    })

    // Eventos
    setupToolbarEvents(appState)
    setupThemeToggle()

  } catch (error) {
    console.error('Error inicializando toolbar:', error)
  }
}

/**
 * Setup de eventos de toolbar
 */
function setupToolbarEvents(appState) {
  // Guardar
  document.getElementById('save-btn')?.addEventListener('click', () => {
    saveWork(appState)
  })

  // Cargar
  document.getElementById('load-btn')?.addEventListener('click', () => {
    loadWork(appState)
  })
}

/**
 * Guardar trabajo en localStorage
 */
function saveWork(appState) {
  try {
    const canvasData = JSON.stringify(appState.canvas.toJSON())
    const timestamp = new Date().toISOString()
    
    localStorage.setItem('pizarra_work', canvasData)
    localStorage.setItem('pizarra_timestamp', timestamp)
    
    showNotification('✓ Trabajo guardado correctamente')
    console.log('Work saved:', timestamp)
  } catch (error) {
    console.error('Error guardando trabajo:', error)
    showNotification('❌ Error al guardar', 'error')
  }
}

/**
 * Cargar trabajo desde localStorage
 */
function loadWork(appState) {
  try {
    const canvasData = localStorage.getItem('pizarra_work')
    const timestamp = localStorage.getItem('pizarra_timestamp')
    
    if (!canvasData) {
      showNotification('No hay trabajo guardado', 'info')
      return
    }

    appState.canvas.loadFromJSON(JSON.parse(canvasData), () => {
      appState.canvas.renderAll()
      showNotification(`✓ Trabajo cargado: ${new Date(timestamp).toLocaleString()}`)
    })
  } catch (error) {
    console.error('Error cargando trabajo:', error)
    showNotification('❌ Error al cargar', 'error')
  }
}

/**
 * Toggle tema oscuro/claro
 */
function setupThemeToggle() {
  const themeToggle = document.getElementById('theme-toggle')
  
  // Detectar tema guardado o preferencia del sistema
  const isDark = localStorage.getItem('theme') === 'dark' || 
                 (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)
  
  if (isDark) {
    document.documentElement.classList.add('dark')
  }

  themeToggle?.addEventListener('click', () => {
    const isDarkNow = document.documentElement.classList.toggle('dark')
    localStorage.setItem('theme', isDarkNow ? 'dark' : 'light')
  })
}

/**
 * Mostrar notificación al usuario
 */
function showNotification(message, type = 'success') {
  const notification = document.createElement('div')
  
  const colors = {
    success: 'bg-green-600',
    error: 'bg-red-600',
    info: 'bg-blue-600'
  }

  notification.className = `fixed bottom-4 left-4 ${colors[type] || colors.success} text-white px-4 py-3 rounded-lg shadow-lg animate-fade-in`
  notification.textContent = message
  
  document.body.appendChild(notification)

  setTimeout(() => {
    notification.remove()
  }, 3000)
}
