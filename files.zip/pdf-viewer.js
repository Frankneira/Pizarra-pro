/**
 * pdf-viewer.js - Gestión de visualización de PDFs
 */

import * as pdfjsLib from 'pdfjs-dist'

/**
 * Inicializar PDF Viewer
 */
export async function initializePDFViewer(appState) {
  try {
    const pdfInput = document.getElementById('pdf-input')
    
    if (!pdfInput) {
      console.warn('PDF input element not found')
      return
    }

    pdfInput.addEventListener('change', (e) => {
      handlePDFUpload(e, appState)
    })

    console.log('PDF Viewer initialized')
  } catch (error) {
    console.error('Error inicializando PDF Viewer:', error)
  }
}

/**
 * Manejar carga de PDF
 */
async function handlePDFUpload(event, appState) {
  try {
    const file = event.target.files[0]
    
    if (!file) {
      return
    }

    // Validar tipo de archivo
    if (file.type !== 'application/pdf') {
      showPDFError('Por favor selecciona un archivo PDF válido')
      return
    }

    // Validar tamaño (10MB máximo)
    const maxSize = 10 * 1024 * 1024
    if (file.size > maxSize) {
      showPDFError('El archivo es demasiado grande (máximo 10MB)')
      return
    }

    // Cargar PDF
    const fileReader = new FileReader()
    
    fileReader.onload = async (e) => {
      try {
        const pdfData = new Uint8Array(e.target.result)
        await loadAndRenderPDF(pdfData, appState)
      } catch (error) {
        console.error('Error cargando PDF:', error)
        showPDFError('Error al procesar el PDF: ' + error.message)
      }
    }

    fileReader.readAsArrayBuffer(file)

  } catch (error) {
    console.error('Error en handlePDFUpload:', error)
    showPDFError('Error al cargar el PDF')
  }
}

/**
 * Cargar y renderizar PDF
 */
async function loadAndRenderPDF(pdfData, appState) {
  try {
    const container = document.getElementById('pdf-container')
    container.innerHTML = '' // Limpiar contenedor anterior

    // Cargar documento PDF
    const pdf = await pdfjsLib.getDocument({ data: pdfData }).promise
    
    console.log(`PDF cargado: ${pdf.numPages} páginas`)

    // Renderizar primera página
    const page = await pdf.getPage(1)
    
    // Crear canvas para la página
    const canvas = document.createElement('canvas')
    const context = canvas.getContext('2d')
    
    // Obtener escala de renderizado
    const viewport = page.getViewport({ scale: 1.5 })
    canvas.width = viewport.width
    canvas.height = viewport.height

    // Renderizar página
    await page.render({
      canvasContext: context,
      viewport: viewport
    }).promise

    // Limpiar contenedor
    container.innerHTML = ''
    
    // Crear wrapper para mejor presentación
    const wrapper = document.createElement('div')
    wrapper.className = 'flex flex-col gap-2'
    
    // Agregar canvas
    wrapper.appendChild(canvas)

    // Agregar información
    const info = document.createElement('div')
    info.className = 'text-xs text-gray-500 dark:text-gray-400 p-2 bg-gray-100 dark:bg-gray-600 rounded'
    info.textContent = `📄 ${pdf.numPages} página${pdf.numPages > 1 ? 's' : ''}`
    wrapper.appendChild(info)

    container.appendChild(wrapper)
    
    console.log('✓ PDF renderizado correctamente')

  } catch (error) {
    console.error('Error renderizando PDF:', error)
    showPDFError('Error al renderizar el PDF: ' + error.message)
  }
}

/**
 * Mostrar error de PDF
 */
function showPDFError(message) {
  const container = document.getElementById('pdf-container')
  if (container) {
    container.innerHTML = `
      <div class="text-center p-4">
        <p class="text-red-600 dark:text-red-400 font-semibold">⚠️ Error</p>
        <p class="text-sm text-gray-600 dark:text-gray-400 mt-2">${message}</p>
      </div>
    `
  }
}

/**
 * Obtener información del PDF
 */
export async function getPDFInfo(pdfData) {
  try {
    const pdf = await pdfjsLib.getDocument({ data: pdfData }).promise
    
    return {
      numPages: pdf.numPages,
      metadata: await pdf.getMetadata(),
      fingerprint: pdf.fingerprint
    }
  } catch (error) {
    console.error('Error obteniendo info del PDF:', error)
    return null
  }
}

/**
 * Renderizar página específica
 */
export async function renderPDFPage(pdfData, pageNum, canvas) {
  try {
    const pdf = await pdfjsLib.getDocument({ data: pdfData }).promise
    const page = await pdf.getPage(pageNum)
    
    const viewport = page.getViewport({ scale: 1.5 })
    const context = canvas.getContext('2d')
    
    canvas.width = viewport.width
    canvas.height = viewport.height

    await page.render({
      canvasContext: context,
      viewport: viewport
    }).promise

    return true
  } catch (error) {
    console.error('Error renderizando página:', error)
    return false
  }
}
