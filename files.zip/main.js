/**
 * PIZARRA DIGITAL PRO+
 * main.js - Punto de entrada principal
 * 
 * Inicializa Fabric.js, PDF.js y gestiona eventos
 */

import { fabric } from 'fabric'
import * as pdfjsLib from 'pdfjs-dist'
import jsPDF from 'jspdf'
import './styles/global.css'
import './styles/tailwind.css'
import { initializeCanvas } from './components/canvas.js'
import { initializeToolbar } from './components/toolbar.js'
import { initializePDFViewer } from './components/pdf-viewer.js'

// Configurar PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`

// Variables globales del estado de la app
let appState = {
  canvas: null,
  currentTool: 'pen',
  brushColor: '#000000',
  brushSize: 3,
  history: [],
  historyStep: -1
}

/**
 * Inicializar la aplicación
 */
async function initializeApp() {
  try {
    console.log('🎨 Inicializando Pizarra Digital PRO+...')

    // 1. Inicializar Canvas
    const canvasElement = document.getElementById('drawing-canvas')
    if (!canvasElement) {
      throw new Error('Canvas element not found')
    }

    appState.canvas = await initializeCanvas(canvasElement)
    console.log('✓ Canvas inicializado')

    // 2. Inicializar Toolbar
    await initializeToolbar(appState)
    console.log('✓ Toolbar inicializado')

    // 3. Inicializar PDF Viewer
    await initializePDFViewer(appState)
    console.log('✓ PDF Viewer inicializado')

    // 4. Configurar event listeners
    setupEventListeners()
    console.log('✓ Event listeners configurados')

    // 5. Resize listener
    window.addEventListener('resize', () => {
      resizeCanvas()
    })

    console.log('✅ Pizarra Digital PRO+ lista')
    
  } catch (error) {
    console.error('❌ Error al inicializar:', error)
    showError('Error al cargar la aplicación: ' + error.message)
  }
}

/**
 * Setup de event listeners generales
 */
function setupEventListeners() {
  // Botones de herramientas
  document.getElementById('pen-tool')?.addEventListener('click', () => {
    appState.currentTool = 'pen'
    appState.canvas.isDrawingMode = true
    appState.canvas.freeDrawingBrush.color = appState.brushColor
    appState.canvas.freeDrawingBrush.width = appState.brushSize
  })

  document.getElementById('eraser-tool')?.addEventListener('click', () => {
    appState.currentTool = 'eraser'
    appState.canvas.isDrawingMode = true
  })

  document.getElementById('clear-tool')?.addEventListener('click', () => {
    if (confirm('¿Estás seguro de que deseas limpiar todo?')) {
      appState.canvas.clear()
      appState.history = []
      appState.historyStep = -1
    }
  })

  // Color picker
  document.getElementById('color-picker')?.addEventListener('change', (e) => {
    appState.brushColor = e.target.value
    if (appState.canvas.freeDrawingBrush) {
      appState.canvas.freeDrawingBrush.color = appState.brushColor
    }
  })

  // Brush size
  document.getElementById('brush-size')?.addEventListener('input', (e) => {
    appState.brushSize = parseInt(e.target.value)
    if (appState.canvas.freeDrawingBrush) {
      appState.canvas.freeDrawingBrush.width = appState.brushSize
    }
  })

  // Undo/Redo
  document.getElementById('undo-btn')?.addEventListener('click', () => {
    undo()
  })

  document.getElementById('redo-btn')?.addEventListener('click', () => {
    redo()
  })

  // Export
  document.getElementById('export-btn')?.addEventListener('click', () => {
    exportCanvas()
  })

  // Guardar automáticamente al cambiar
  appState.canvas?.on('object:added', saveHistory)
  appState.canvas?.on('object:modified', saveHistory)
}

/**
 * Redimensionar canvas al cambiar ventana
 */
function resizeCanvas() {
  const container = document.querySelector('main > div:first-child')
  if (container && appState.canvas) {
    appState.canvas.setWidth(container.offsetWidth)
    appState.canvas.setHeight(container.offsetHeight)
    appState.canvas.renderAll()
  }
}

/**
 * Guardar estado en historial
 */
function saveHistory() {
  appState.historyStep += 1
  if (appState.historyStep < appState.history.length) {
    appState.history.length = appState.historyStep
  }
  appState.history.push(JSON.stringify(appState.canvas.toJSON()))
}

/**
 * Deshacer
 */
function undo() {
  if (appState.historyStep > 0) {
    appState.historyStep -= 1
    appState.canvas.loadFromJSON(
      appState.history[appState.historyStep],
      () => appState.canvas.renderAll()
    )
  }
}

/**
 * Rehacer
 */
function redo() {
  if (appState.historyStep < appState.history.length - 1) {
    appState.historyStep += 1
    appState.canvas.loadFromJSON(
      appState.history[appState.historyStep],
      () => appState.canvas.renderAll()
    )
  }
}

/**
 * Exportar canvas a PNG
 */
function exportCanvas() {
  try {
    const loading = document.getElementById('loading-indicator')
    loading.classList.remove('hidden')

    const dataURL = appState.canvas.toDataURL({
      format: 'png',
      quality: 1,
      multiplier: 2
    })

    const link = document.createElement('a')
    link.href = dataURL
    link.download = `pizarra-${new Date().toISOString().slice(0, 10)}.png`
    link.click()

    loading.classList.add('hidden')
    console.log('✓ Canvas exportado correctamente')
  } catch (error) {
    console.error('Error al exportar:', error)
    showError('Error al exportar: ' + error.message)
  }
}

/**
 * Mostrar error al usuario
 */
function showError(message) {
  const errorDiv = document.createElement('div')
  errorDiv.className = 'fixed top-4 right-4 bg-red-600 text-white px-4 py-3 rounded-lg shadow-lg'
  errorDiv.textContent = message
  document.body.appendChild(errorDiv)

  setTimeout(() => {
    errorDiv.remove()
  }, 5000)
}

// Iniciar app cuando DOM esté listo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeApp)
} else {
  initializeApp()
}

// Hot Module Replacement (desarrollo)
if (import.meta.hot) {
  import.meta.hot.accept()
}
