/**
 * helpers.js - Funciones auxiliares generales
 */

/**
 * Validar archivo
 */
export function validateFile(file, { maxSize = 10485760, allowedTypes = ['application/pdf'] } = {}) {
  // Validar existencia
  if (!file) {
    return { valid: false, error: 'No se seleccionó archivo' }
  }

  // Validar tipo
  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: 'Tipo de archivo no permitido' }
  }

  // Validar tamaño
  if (file.size > maxSize) {
    return { 
      valid: false, 
      error: `Archivo demasiado grande. Máximo: ${(maxSize / 1024 / 1024).toFixed(2)}MB` 
    }
  }

  return { valid: true }
}

/**
 * Formatear fecha
 */
export function formatDate(date, format = 'es-ES') {
  return new Date(date).toLocaleDateString(format, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

/**
 * Debounce función
 */
export function debounce(func, wait = 300) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

/**
 * Throttle función
 */
export function throttle(func, wait = 300) {
  let timeout = null
  let previous = 0

  return function executedFunction(...args) {
    const now = Date.now()
    const remaining = wait - (now - previous)

    if (remaining <= 0 || remaining > wait) {
      if (timeout) {
        clearTimeout(timeout)
        timeout = null
      }
      previous = now
      func.apply(this, args)
    } else if (!timeout) {
      timeout = setTimeout(() => {
        previous = Date.now()
        timeout = null
        func.apply(this, args)
      }, remaining)
    }
  }
}

/**
 * Generar ID único
 */
export function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

/**
 * Copiar al portapapeles
 */
export async function copyToClipboard(text) {
  try {
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(text)
      return true
    } else {
      // Fallback para navegadores antiguos
      const textarea = document.createElement('textarea')
      textarea.value = text
      document.body.appendChild(textarea)
      textarea.select()
      document.execCommand('copy')
      document.body.removeChild(textarea)
      return true
    }
  } catch (error) {
    console.error('Error copiando al portapapeles:', error)
    return false
  }
}

/**
 * Descargar archivo
 */
export function downloadFile(dataUrl, filename) {
  try {
    const link = document.createElement('a')
    link.href = dataUrl
    link.download = filename
    link.click()
    return true
  } catch (error) {
    console.error('Error descargando archivo:', error)
    return false
  }
}

/**
 * Verificar soporte de características
 */
export function checkFeatureSupport() {
  return {
    canvas: typeof HTMLCanvasElement !== 'undefined',
    localStorage: typeof Storage !== 'undefined',
    fetch: typeof fetch !== 'undefined',
    blob: typeof Blob !== 'undefined',
    worker: typeof Worker !== 'undefined',
    darkMode: window.matchMedia('(prefers-color-scheme: dark)').matches
  }
}

/**
 * Obtener información del dispositivo
 */
export function getDeviceInfo() {
  return {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    onLine: navigator.onLine,
    cookiesEnabled: navigator.cookieEnabled,
    screen: {
      width: window.screen.width,
      height: window.screen.height,
      colorDepth: window.screen.colorDepth
    }
  }
}

/**
 * Medir rendimiento
 */
export function measurePerformance(label, fn) {
  const start = performance.now()
  const result = fn()
  const end = performance.now()
  
  console.log(`⏱️ ${label}: ${(end - start).toFixed(2)}ms`)
  return result
}

/**
 * Hacer retardo
 */
export function delay(ms = 1000) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

/**
 * Retry con exponential backoff
 */
export async function retryWithBackoff(fn, maxRetries = 3, delay = 1000) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn()
    } catch (error) {
      if (i === maxRetries - 1) throw error
      
      const waitTime = delay * Math.pow(2, i)
      console.warn(`Reintentando en ${waitTime}ms...`)
      await new Promise(resolve => setTimeout(resolve, waitTime))
    }
  }
}

/**
 * Colorizar texto para consola
 */
export const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
}

export function colorLog(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`)
}
